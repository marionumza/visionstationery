odoo.define('sync.uppercrust.crm', function (require) {
'use strict';
    var core = require('web.core');
    core.qweb.add_template('/sync_uppercrust_crm/static/src/xml/templates.xml');
});